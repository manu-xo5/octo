#!/usr/bin/env python
      

import time
import serial
import struct
import binascii
import os
import subprocess
import time

## Setup the serial connection
ser = serial.Serial(
  
    port='/dev/ttyS0',
    baudrate = 115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    
    timeout=1
)

print '\n \n BT SIG HCI command parser, 27-1-16 \n \n'

## Send an initial reset to BT to make sure everything starts correctly
## cmd is a list of commands to be send to popen, not a string 
cmd = ['sudo', 'hcitool', 'cmd',  '03' , '03']

## Use popen to send a command, take stdout from communicate
proc = subprocess.Popen(cmd , stdout=subprocess.PIPE,)
stdout_value = proc.communicate()[0]

## Communicate gives us the whole output, we split it into lines and take the 
## relevant response to be printed (sanity check)
ret_value = stdout_value.splitlines()
print '\Reset response:', repr(ret_value[2])

## Run this loop forever, use readline(large number), could cause an issue later on?

while 1:
    ## Read line and provided it is not empty continue
    x=ser.readline(256)

    if len(x) != 0:

      ## Recived data is ASCII formatted, convert this to HEX
      z = binascii.hexlify(x)
      
      ## turn it into a useable list of commands (each is a byte)
      y = map(''.join, zip(*[iter(z)]*2))
      print y  
      
      ## Start to build list of commands to be sent.
      hcicmd = ['sudo', 'hcitool', 'cmd']     

      if y[0] != '00':
        print y
        ## OCF is the first command needed, it is the y[2] shifted >> by two bits. and then added to the command
        ocf = (int(y[2],16)>>2)
        ocf = format(ocf, '02x')
        #hcicmd.append(ocf)       
        
        ## filter out the LE and general tests
        print ocf
        if ocf == '03':
          hcicmd.append('03')  
        else:
          hcicmd.append('08')            
        
        
        ## The length of trailing data is y[3], convert to dec for loop
        #msg_length = int(y[3]) 
        msg_length = int(y[3],16) 
        print msg_length
          
        ## Some commands don't have any data so we check this.
        ## If it does have data, we add each byte to the end of the command.
        if msg_length != 0 :
          hcicmd.append(y[1]) 
          for msg in range(1,msg_length+1):
            hcicmd.append(y[msg+3])
        else:
          hcicmd.append(y[1])
        
        ## Print out final command for debug
        print 'HCIcmd sent to BCM43438', hcicmd
        
        ## Use Popen to send the command and get response 
        ## We take the response and format it to send back to tester.
        proc = subprocess.Popen(hcicmd , stdout=subprocess.PIPE,)
        stdout_value = proc.communicate()[0]
        ret_value = stdout_value.splitlines()
        
        print ret_value
        
        ## We take the last returend value as the data recieved back
    
        pos = len(ret_value)-1
        y = ret_value[pos]
  
          
          
        print 'Cmd response:', repr(y)      
          
        ## Remove whitespace from returned data
        y = ''.join(y.split())
        
        ## Work out length of data to be sent back and format it appropiately.
        msg_length = len(y)/2
        msg_length = format(msg_length, '02x')
  
        ## Responses (event complete) from the device are prefixed 
        prefix = '040E'
        
        ## Complete the message to be sent back
        reply_data = prefix + msg_length + y 
      
        ## Convert back to ASCII 
        z = binascii.unhexlify(reply_data)
        
        ##Send data back
        x=ser.write(z)      
      
      

      
